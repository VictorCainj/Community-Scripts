onCreatureHealthPercentChange(function(creature, hpPercent)
    creature:setText(hpPercent .. '%')
end);