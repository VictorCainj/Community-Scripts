macro(20, "Dance", function()
    turn(math.random(0, 3)) 
end);
